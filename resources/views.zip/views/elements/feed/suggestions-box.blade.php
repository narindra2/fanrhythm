<p class="aff_title_feed">
    {{__('Suggestions')}}
</p>
@include('elements.feed.suggestions-wrapper',['profiles'=>$profiles])
