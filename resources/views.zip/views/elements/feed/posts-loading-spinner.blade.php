<div class="d-flex align-items-center justify-content-center posts-loading-indicator">
    <div class="py-3 spinner d-none">
        <div class="spinner-border text-primary" role="status">
            <span class="sr-only">{{__("Loading...")}}</span>
        </div>
    </div>
</div>
