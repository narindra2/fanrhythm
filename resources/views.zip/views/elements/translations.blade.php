<script>
    window.translations = {!! Session::get('translations') !!};
</script>
