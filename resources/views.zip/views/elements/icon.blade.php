{!!IconsHelper::readIcon($icon, isset($variant) ? $variant : '', isset($centered) ? $centered : true, isset($classes) ? $classes : '')!!}
