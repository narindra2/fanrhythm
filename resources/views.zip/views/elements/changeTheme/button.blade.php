<div class="d-flex align-items-center mr-3">
    <label id="label-theme-active" for="change-theme" class="link_register mb-0" style="cursor: pointer;font-size: 14px; color: var(--base-color)">
        Dark mode
    </label>
    <button id="change-theme" class="theme-btn active" aria-label="Change Theme" title="Change Theme" data-theme-btn="">
        <span class="icon"></span>
    </button>
</div>