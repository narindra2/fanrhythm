<script type="text/javascript" src="https://hw-cdn2.adtng.com/delivery/idsync/idsync.min.js" defer></script>
<script>
    // window.idsync.config(34542).fp_get().sync();
</script>