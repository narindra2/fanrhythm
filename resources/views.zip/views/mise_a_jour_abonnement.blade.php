{{-- resources/views/abonnement/mise_a_jour_abonnement.blade.php --}}
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mise à jour des abonnements</title>
</head>
<body>
    <h1>Mise à jour des abonnements</h1>
    <p>Cette page effectue une mise à jour des abonnements.</p>
</body>
</html>
