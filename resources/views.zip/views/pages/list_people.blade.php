@extends('layouts.user-no-nav')

@section('content')

Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro officia exercitationem aspernatur temporibus dolores eos reprehenderit quibusdam nam facere ducimus sunt quisquam quis, quos expedita atque, deserunt id consequuntur quidem.

@stop
