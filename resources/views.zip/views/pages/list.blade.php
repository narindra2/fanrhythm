@extends('layouts.user-no-nav')
@section('page_title', $list->name)

@section('styles')
{!!
Minify::stylesheet([
'/css/pages/lists.css'
])->withFullUrl()
!!}
@stop

@section('scripts')
{!!
Minify::javascript([
'/js/pages/lists.js'
])->withFullUrl()
!!}
@stop

@section('content')

<div id="aff_content">
    <div class="aff_gauche">
        <div class="aff_title_feed aff_title_with_editable_list">
            <a href="{{route('my.lists.all')}}">
                <svg width="7px" height="12px" viewBox="0 0 7 12" version="1.1" xmlns="http://www.w3.org/2000/svg"
                    xmlns:xlink="http://www.w3.org/1999/xlink">
                    <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round"
                        stroke-linejoin="round">
                        <g id="Reglages---profil" transform="translate(-541.000000, -54.000000)" stroke="#000000"
                            stroke-width="2">
                            <polyline id="Path"
                                transform="translate(544.500000, 60.000000) scale(-1, 1) translate(-544.500000, -60.000000) "
                                points="542 65 547 60 542 55"></polyline>
                        </g>
                    </g>
                </svg>
                {{__($list->name)}}
            </a>

            @if($list->isManageable)
            
            <div class="dropdown {{GenericHelper::getSiteDirection() == 'rtl' ? 'dropright' : 'dropleft'}}">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"
                        role="button" aria-haspopup="true" aria-expanded="false">            
                        <svg width="16px" height="16px" viewBox="0 0 16 16" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                            <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" stroke-linecap="round" stroke-linejoin="round">
                                <g id="Listes" transform="translate(-1174.000000, -43.000000)" stroke="#000000" stroke-width="2">
                                    <g id="settings" transform="translate(1175.000000, 44.000000)">
                                        <circle id="Oval" cx="7" cy="7" r="1.90909091"></circle>
                                        <path d="M11.7090909,8.90909091 C11.5357795,9.30178459 11.6189399,9.76042662 11.9190909,10.0672727 L11.9572727,10.1054545 C12.1962617,10.3441778 12.3305467,10.6681155 12.3305467,11.0059091 C12.3305467,11.3437027 12.1962617,11.6676404 11.9572727,11.9063636 C11.7185495,12.1453526 11.3946118,12.2796376 11.0568182,12.2796376 C10.7190246,12.2796376 10.3950869,12.1453526 10.1563636,11.9063636 L10.1181818,11.8681818 C9.81133571,11.5680308 9.35269368,11.4848704 8.96,11.6581818 C8.57533689,11.8230435 8.32530549,12.2005909 8.32363636,12.6190909 L8.32363636,12.7272727 C8.32363636,13.4301806 7.75381695,14 7.05090909,14 C6.34800123,14 5.77818182,13.4301806 5.77818182,12.7272727 L5.77818182,12.67 C5.76809966,12.2389723 5.49555476,11.8579142 5.09090909,11.7090909 C4.69821541,11.5357795 4.23957338,11.6189399 3.93272727,11.9190909 L3.89454545,11.9572727 C3.65582222,12.1962617 3.3318845,12.3305467 2.99409091,12.3305467 C2.65629732,12.3305467 2.3323596,12.1962617 2.09363636,11.9572727 C1.8546474,11.7185495 1.72036244,11.3946118 1.72036244,11.0568182 C1.72036244,10.7190246 1.8546474,10.3950869 2.09363636,10.1563636 L2.13181818,10.1181818 C2.43196919,9.81133571 2.51512956,9.35269368 2.34181818,8.96 C2.17695655,8.57533689 1.79940913,8.32530549 1.38090909,8.32363636 L1.27272727,8.32363636 C0.569819409,8.32363636 0,7.75381695 0,7.05090909 C0,6.34800123 0.569819409,5.77818182 1.27272727,5.77818182 L1.33,5.77818182 C1.76102766,5.76809966 2.1420858,5.49555476 2.29090909,5.09090909 C2.46422047,4.69821541 2.3810601,4.23957338 2.08090909,3.93272727 L2.04272727,3.89454545 C1.80373831,3.65582222 1.66945335,3.3318845 1.66945335,2.99409091 C1.66945335,2.65629732 1.80373831,2.3323596 2.04272727,2.09363636 C2.28145051,1.8546474 2.60538823,1.72036244 2.94318182,1.72036244 C3.28097541,1.72036244 3.60491313,1.8546474 3.84363636,2.09363636 L3.88181818,2.13181818 C4.18866429,2.43196919 4.64730632,2.51512956 5.04,2.34181818 L5.09090909,2.34181818 C5.47557221,2.17695655 5.72560361,1.79940913 5.72727273,1.38090909 L5.72727273,1.27272727 C5.72727273,0.569819409 6.29709214,0 7,0 C7.70290786,0 8.27272727,0.569819409 8.27272727,1.27272727 L8.27272727,1.33 C8.27439639,1.74850004 8.52442779,2.12604746 8.90909091,2.29090909 C9.30178459,2.46422047 9.76042662,2.3810601 10.0672727,2.08090909 L10.1054545,2.04272727 C10.3441778,1.80373831 10.6681155,1.66945335 11.0059091,1.66945335 C11.3437027,1.66945335 11.6676404,1.80373831 11.9063636,2.04272727 C12.1453526,2.28145051 12.2796376,2.60538823 12.2796376,2.94318182 C12.2796376,3.28097541 12.1453526,3.60491313 11.9063636,3.84363636 L11.8681818,3.88181818 C11.5680308,4.18866429 11.4848704,4.64730632 11.6581818,5.04 L11.6581818,5.09090909 C11.8230435,5.47557221 12.2005909,5.72560361 12.6190909,5.72727273 L12.7272727,5.72727273 C13.4301806,5.72727273 14,6.29709214 14,7 C14,7.70290786 13.4301806,8.27272727 12.7272727,8.27272727 L12.67,8.27272727 C12.2515,8.27439639 11.8739525,8.52442779 11.7090909,8.90909091 Z" id="Path"></path>
                                    </g>
                                </g>
                            </g>
                        </svg>
                    </a>
                    <div class="dropdown-menu">
                        <!-- Dropdown menu links -->
                        <a class="dropdown-item" href="javascript:void(0);"
                            onclick="Lists.showListEditDialog('edit')">{{__('Rename list')}}</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#"
                            onclick="Lists.showListClearConfirmation()">{{__('Clear list')}}</a>
                        <a class="dropdown-item" href="javascript:void(0);"
                            onclick="Lists.showListDeleteConfirmation()">{{__('Delete list')}}</a>
                    </div>
                </div>
            @endif

        </div>


      
        @if(count($list->members))
    
        @foreach($list->members as $member)
            @include('elements.feed.suggestion-card-list',['profile' => $member->user, 'isListMode' => true])
        @endforeach


        @else
        <div class="aff_privacy_devices_not_ok aff_privacy_devices_not_ok_no_padding">
             Cette liste est encore vide
        </div>
        @endif

    </div>
</div>


@include('elements.lists.list-update-dialog',['mode'=>'edit'])
@include('elements.lists.list-delete-dialog')
@include('elements.lists.list-member-delete-dialog')
@include('elements.lists.list-clear-dialog')
@stop
